package com.shiviishiv7.matchmaking.processor.userprofile;

import com.shiviishiv7.matchmaking.common.exception.MatchmakingException;
import com.shiviishiv7.matchmaking.provider.vo.BaseVO;
import com.shiviishiv7.matchmaking.provider.vo.FlatmateExtProfileVO;

public interface IFlatmateExtProfileProcessor {

    BaseVO add(FlatmateExtProfileVO vo) throws MatchmakingException;

    BaseVO update(FlatmateExtProfileVO vo) throws MatchmakingException;

    BaseVO getById(String id) throws MatchmakingException;

    BaseVO getByUserId(String userId) throws MatchmakingException;

    BaseVO delete(String id) throws MatchmakingException;
}
