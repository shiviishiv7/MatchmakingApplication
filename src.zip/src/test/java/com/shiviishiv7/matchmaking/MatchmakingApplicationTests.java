package com.shiviishiv7.matchmaking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchmakingApplicationTests {

	@Test
	void contextLoads() {
	}

}
